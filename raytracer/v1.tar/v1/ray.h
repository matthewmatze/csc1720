#include<iostream>
#include<fstream>
#include<cassert>
#include<cstdlib>

#define NAME_LEN 16
using namespace std;

#ifndef ENTITIES
#define ENTITIES
enum entity_type {CAMERA, LIGHT, MATERIAL, PLANE};

const string entities[] =
{
   "camera",
   "light",
   "material",
   "plane"
};

#define NUM_ENTITIES (sizeof(entities) / sizeof(entities[0]))
#endif

#ifndef ATTRIBUTES
#define ATTRIBUTES
enum attribute_type {PIXELDIM, WORLDDIM, VIEWPOINT, DIFFUSE, 
                     AMBIENT,  SPECULAR, AMATERIAL, NORMAL, POINT};

const string attributes[] =
{
   "pixeldim",
   "worlddim",
   "viewpoint",
   "diffuse",
   "ambient",
   "specular",
   "material",
   "normal",
   "point"
};

#define NUM_ATTRIBUTES (sizeof(attributes) / sizeof(attributes[0]))
#endif

#include"rayhdrs.h"
