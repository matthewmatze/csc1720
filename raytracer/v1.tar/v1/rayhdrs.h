int table_lookup(const string table[], int len, const string &sv);
